# Rotary encoder library
